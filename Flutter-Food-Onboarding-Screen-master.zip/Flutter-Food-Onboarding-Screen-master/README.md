# Flutter food onboarding screen

A beautiful food onboarding screen which can be used when building a food related flutter app for both android and IOS.

![preview](https://user-images.githubusercontent.com/48721096/71484794-4aaa6680-281f-11ea-97c9-8186918450bd.png)

Video Preview: http://bit.ly/35gkaeA

Android Demo APK: http://bit.ly/2Zr1p6Z
