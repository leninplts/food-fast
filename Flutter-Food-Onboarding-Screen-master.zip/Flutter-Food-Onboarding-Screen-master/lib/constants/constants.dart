class Constants{
  static const String POPPINS = "Poppins";
  static const String OPEN_SANS = "OpenSans";
  static const String SKIP = "Skip";
  static const int DOT_ACTIVE_SIZE = 8;
  static const double DOT_NOT_SIZE = 5.0;
  static const String GET_STARTED = "GET STARTED";
  static const String SLIDER_HEADING_1 = "FIND RESTAURANT";
  static const String SLIDER_HEADING_2 = "PICK THE BEST";
  static const String SLIDER_HEADING_3 = "CHOOSE YOUR MEAL";
  static const String SLIDER_DESC = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla ultricies, erat vitae porta consequat.";

}