# Changelog


## [1.2.0] - Current Release
- Context issue fixed

## [1.1.3] - Current Release
- No need of context when navigating

## [1.1.2] - Current Release
- console output in skip button fix

## [1.1.1] - Current Release
- Home route bug fixed
- Image Url bug fix

## [1.0.0] - Current Release
- Added Example
- Fix Android crashes

## [0.0.1] - Initial Release
