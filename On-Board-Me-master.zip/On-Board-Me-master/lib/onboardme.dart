library onboardme;

export 'src/on_boarding_me.dart';
